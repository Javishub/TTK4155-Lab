/*
 * Node2.c
 *
 * Created: 12.10.2023 15:43:32
 * Author : larskrud
 */ 

#include "sam.h"
#include "delay.h"
#include "asf.h"
#include "uart.c"
#include "printf-stdarg.c"

int main(void)
{
    /* Initialize the SAM system */
    SystemInit();
	board_init();
	
	PIOA->PIO_OER = PIO_PA19;

    /* Replace with your application code */
    while (1) 
    {
		printf("h");
		PIOA->PIO_SODR = PIO_PA19;
		delay_ms(500);
		PIOA->PIO_CODR = PIO_PA19;
		delay_ms(500);
    }
}
